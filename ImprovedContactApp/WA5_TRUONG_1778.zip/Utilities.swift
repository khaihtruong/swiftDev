//
//  Utilities.swift
//  ImprovedContactApp
//
//  Created by Khai Truong on 10/12/24.
//

import Foundation
class Utilities{
    static let types = ["Cell", "Home", "Work"]
}
