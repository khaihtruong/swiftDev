//
//  Configs.swift
//  NoteApp
//
//  Created by Khai Truong on 11/3/24.
//

import Foundation
class Configs{
    static let tableViewContactsID = "tableViewContactsID"
}
