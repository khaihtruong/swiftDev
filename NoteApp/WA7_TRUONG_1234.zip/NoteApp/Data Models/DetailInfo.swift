//
//  DetailInfo.swift
//  NoteApp
//
//  Created by Khai Truong on 11/4/24.
//

import Foundation

struct DetailInfo: Codable{
    var _id: String
    var name: String
    var email: String
    var __v: Int
}
