//
//  Token.swift
//  NoteApp
//
//  Created by Khai Truong on 11/3/24.
//

import Foundation

struct Token: Decodable{
    let auth: Bool
    let token: String
}
