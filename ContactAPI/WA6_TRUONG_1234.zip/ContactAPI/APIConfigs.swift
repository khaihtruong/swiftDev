//
//  APIConfigs.swift
//  ContactAPI
//
//  Created by Khai Truong on 10/21/24.
//

import Foundation

class APIConfigs{
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.work:8888/contacts/text/"
}
